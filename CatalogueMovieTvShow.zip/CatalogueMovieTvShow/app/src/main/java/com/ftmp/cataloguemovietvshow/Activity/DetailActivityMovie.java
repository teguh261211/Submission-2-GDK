package com.ftmp.cataloguemovietvshow.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.ftmp.cataloguemovietvshow.R;

public class DetailActivityMovie extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);
    }
}
