package com.ftmp.cataloguemovietvshow.Activity;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;

import com.ftmp.cataloguemovietvshow.Fragment.MovieFragment;
import com.ftmp.cataloguemovietvshow.Fragment.TvShowFragment;
import com.ftmp.cataloguemovietvshow.R;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_movies:
                    MovieFragment movieFragment = new MovieFragment();
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.content , movieFragment);
                    fragmentTransaction.commit();
                    return true;
                case R.id.navigation_tvshow:
                    TvShowFragment tvShowFragment = new TvShowFragment();
                    FragmentTransaction fragmentTvTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTvTransaction .replace(R.id.content , tvShowFragment);
                    fragmentTvTransaction .commit();
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MovieFragment movieFragment = new MovieFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.content , movieFragment);
        fragmentTransaction.commit();

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }

}
